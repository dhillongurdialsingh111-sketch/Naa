package com.example.ziostartv;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;


/** Android 9-compatible, remote-first wrapper around the supplied ZioStar web interface. */
public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private FrameLayout root;
    private ExoPlayer player;
    private PlayerView playerView;
    private View webContainer;
    private String lastPage = "file:///android_asset/index.html";
    private boolean playerOpen = false;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.rgb(5,5,5));
        getWindow().setNavigationBarColor(Color.rgb(5,5,5));
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);
        webContainer = new FrameLayout(this);
        root.addView(webContainer, new FrameLayout.LayoutParams(-1, -1));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(5,5,5));
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true); // Local bundled UI must fetch the configured HTTPS channel APIs.
        settings.setAllowContentAccess(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setBlockNetworkImage(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setDefaultTextEncodingName("UTF-8");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.addJavascriptInterface(new AndroidPortal(), "AndroidPortal");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equalsIgnoreCase(uri.getScheme()) && (uri.getHost() == null || uri.getHost().isEmpty())) return false;
                // Keep the JavaScript bridge confined to the bundled, trusted local UI.
                if ("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                }
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                lastPage = url;
                // First focus target should work with a TV remote from launch.
                view.evaluateJavascript("setTimeout(function(){var x=document.querySelector('.card,.chip,.menu-trigger,.search-icon-btn');if(x)x.focus()},350)", null);
            }
        });
        ((FrameLayout) webContainer).addView(webView, new FrameLayout.LayoutParams(-1, -1));
        webView.loadUrl(lastPage);
    }

    private class AndroidPortal {
        @JavascriptInterface public void launchNative(String urlData, String name, String category) {
            runOnUiThread(() -> startStream(urlData, name));
        }
    }

    private void startStream(String raw, String name) {
        if (raw == null || raw.trim().isEmpty()) {
            Toast.makeText(this, "No stream URL is available for this channel.", Toast.LENGTH_LONG).show();
            return;
        }
        // The supplied page appends optional metadata using |Cookie= and |drmLicense=.
        // This starter player supports direct HLS/DASH URLs. See README for DRM caveats.
        String[] parts = raw.split("\\|");
        String stream = parts[0].trim();
        String cookie = null;
        String drm = null;
        for (int i = 1; i < parts.length; i++) {
            String p = parts[i];
            if (p.regionMatches(true, 0, "Cookie=", 0, 7)) cookie = p.substring(7);
            if (p.regionMatches(true, 0, "drmLicense=", 0, 11)) drm = p.substring(11);
        }
        Uri uri = Uri.parse(stream);
        if (!"https".equalsIgnoreCase(uri.getScheme()) && !"http".equalsIgnoreCase(uri.getScheme())) {
            Toast.makeText(this, "This stream link is not a valid HTTP(S) URL.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            releasePlayer();
            DefaultHttpDataSource.Factory httpFactory = new DefaultHttpDataSource.Factory()
                    .setUserAgent("ZioStarTV/1.0 (Android TV)")
                    .setAllowCrossProtocolRedirects(true);
            if (cookie != null && !cookie.trim().isEmpty()) {
                java.util.Map<String, String> headers = new java.util.HashMap<>();
                headers.put("Cookie", cookie);
                httpFactory.setDefaultRequestProperties(headers);
            }
            DefaultDataSource.Factory dataSourceFactory = new DefaultDataSource.Factory(this, httpFactory);
            DefaultMediaSourceFactory mediaSourceFactory = new DefaultMediaSourceFactory(dataSourceFactory);
            player = new ExoPlayer.Builder(this).setMediaSourceFactory(mediaSourceFactory).build();
            playerView = new PlayerView(this);
            playerView.setUseController(true);
            playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS);
            playerView.setPlayer(player);
            playerView.setFocusable(true);
            playerView.setFocusableInTouchMode(true);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -1);
            root.addView(playerView, lp);
            webContainer.setVisibility(View.GONE);
            playerOpen = true;

            MediaItem.Builder mediaItemBuilder = new MediaItem.Builder().setUri(uri).setMediaId(name == null ? "Live channel" : name);
            if (drm != null && (drm.startsWith("https://") || drm.startsWith("http://"))) {
                mediaItemBuilder.setDrmConfiguration(new MediaItem.DrmConfiguration.Builder(C.WIDEVINE_UUID)
                        .setLicenseUri(drm).build());
            }
            MediaItem item = mediaItemBuilder.build();
            player.setMediaItem(item);
            player.addListener(new Player.Listener() {
                @Override public void onPlayerError(PlaybackException error) {
                    Toast.makeText(MainActivity.this, "Playback failed: " + error.getErrorCodeName() + ". This stream may need DRM or special headers.", Toast.LENGTH_LONG).show();
                }
            });
            player.prepare();
            player.play();
            playerView.requestFocus();
        } catch (Exception e) {
            Toast.makeText(this, "Cannot open stream: " + e.getMessage(), Toast.LENGTH_LONG).show();
            closePlayer();
        }
    }

    private void releasePlayer() {
        if (player != null) { player.release(); player = null; }
        if (playerView != null) { root.removeView(playerView); playerView = null; }
    }

    private void closePlayer() {
        releasePlayer();
        playerOpen = false;
        if (webContainer != null) webContainer.setVisibility(View.VISIBLE);
        if (webView != null) webView.requestFocus();
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN && playerOpen &&
                (event.getKeyCode() == KeyEvent.KEYCODE_BACK || event.getKeyCode() == KeyEvent.KEYCODE_ESCAPE)) {
            closePlayer();
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override public void onBackPressed() {
        if (playerOpen) { closePlayer(); return; }
        if (webView != null) {
            webView.evaluateJavascript("(function(){var s=document.getElementById('sidebar');if(s&&s.classList.contains('open')){if(typeof toggleMenu==='function')toggleMenu();return true;}var t=document.getElementById('searchTab');if(t&&getComputedStyle(t).display!=='none'){if(typeof toggleSearch==='function')toggleSearch();return true;}return false;})()", value -> {
                if (!"true".equals(value)) {
                    if (webView != null && webView.canGoBack()) webView.goBack();
                    else MainActivity.super.onBackPressed();
                }
            });
            return;
        }
        super.onBackPressed();
    }

    @Override protected void onStop() {
        if (player != null) player.pause();
        super.onStop();
    }

    @Override protected void onDestroy() {
        releasePlayer();
        if (webView != null) { webView.loadUrl("about:blank"); webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
