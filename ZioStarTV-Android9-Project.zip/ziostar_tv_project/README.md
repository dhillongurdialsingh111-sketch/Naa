# ZioStar+ TV (Android 9 / Android TV)

This project adapts the bundled ZioStar+ HTML interface for landscape Android TV use and sets Android API 28 (Android 9) as the target SDK. It adds a Leanback launcher entry, disables dependence on a touchscreen, enables TV remote navigation, uses a bundled icon/banner, and supplies an Android-side playback bridge backed by Media3 ExoPlayer.

## Build the APK using GitHub Actions

This environment does not contain the Android SDK or Gradle, and cannot download them. The repository includes a GitHub Actions workflow that builds the APK on GitHub-hosted runners.

1. Create a GitHub repository.
2. Upload all files and folders from this project to its root (keep the `.github/workflows` directory).
3. Open the repository's **Actions** tab and run **Build Android TV APK**, or push to `main`/`master`.
4. Open the completed workflow run and download the artifact named **ZioStarTV-Android9-APK**.
5. Install `app-debug.apk` on the Android 9 TV. For Android TV installation, use ADB or copy the APK to a USB drive and open it with a file manager that supports APK installation.

## Important playback limitations

- The original web UI expects the Android bridge method `AndroidPortal.launchNative(...)`; this project implements that bridge for direct HLS/DASH streams and HTTP(S) Widevine license URLs.
- Some feeds may require headers other than Cookie, a custom DRM flow, device certification, or a proprietary native player. Such feeds may not play in this replacement player. This cannot be fully verified without the TV and working/authorized test streams.
- The original HTML references its configured public channel-data APIs. Availability and legality of any channel/stream are controlled by those remote sources, not by this app.
- The app bundle contains only the UI assets extracted from the provided APK; it does not reuse the original closed-source native player implementation.

## Build settings

- `minSdk`: 21
- `targetSdk`: 28 (Android 9 compatibility target)
- `compileSdk`: 35
- Android TV launcher category: `LEANBACK_LAUNCHER`
- UI: bundled WebView HTML, landscape, remote-first navigation
- Playback: AndroidX Media3 ExoPlayer with HLS/DASH modules
- Cleartext HTTP is enabled for compatibility with older streams; prefer HTTPS streams where available.

The first build produced by CI is a **debug-signed** APK for testing, not a release-signed production package.
